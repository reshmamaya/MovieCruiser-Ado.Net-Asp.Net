﻿using System;
using System.Globalization;

namespace com.cognizant.movie.util {
    public class DateUtil {
        public static DateTime convertToDate(string date) {
            DateTime dt = DateTime.ParseExact(date, "dd/MM/yyyy", null);
            return dt;
        }
    }
}
