﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
public partial class _Default : System.Web.UI.Page{

    protected void Page_Load(object sender, EventArgs e){
        if (!IsPostBack){
            lblMessage.Text = "";
            DisplayMoviesCustomers();
        }
    }

    protected void GridMovieAddbuttonClick(object sender, GridViewCommandEventArgs e){
        int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
        FavoriteDaoSqlImpl favoriteDao = new FavoriteDaoSqlImpl();
        string movieId = gridMovie.Rows[gridviewrowindex].Cells[0].Text;
        favoriteDao.AddFavorite(1, long.Parse(movieId));
        lblMessage.Text = "Movie added to the Favorites Successfully";
    }

    protected void GridMovieRowDataBound(object sender, GridViewRowEventArgs e){
        if (e.Row.Cells[3].Text == "True"){
            e.Row.Cells[3].Text = "Yes";
        }
        if (e.Row.Cells[3].Text == "False"){
            e.Row.Cells[3].Text = "No";
        }
        if (e.Row.Cells[6].Text == "True"){
            e.Row.Cells[6].Text = "Yes";
        }
        if (e.Row.Cells[6].Text == "False"){
            e.Row.Cells[6].Text = "No";
        }
        double value;
        if (double.TryParse(e.Row.Cells[2].Text, out value))
        {
            e.Row.Cells[2].Text = "$ &nbsp;" + value.ToString("N0");
        }

    }

    protected void DisplayMoviesCustomers(){
        MovieDaoSqlImpl movieDao = new MovieDaoSqlImpl();
        List<com.cognizant.movie.model.Movie> movieList = movieDao.GetMovieListCustomer();
        gridMovie.DataSource = movieList;
        gridMovie.DataBind();
    }

}