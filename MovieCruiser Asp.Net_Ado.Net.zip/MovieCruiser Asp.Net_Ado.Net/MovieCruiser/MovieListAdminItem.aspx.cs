﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;
public partial class _Default : System.Web.UI.Page{

    protected void Page_Load(object sender, EventArgs e) { 
        if (!IsPostBack){
            DisplayMoviesAdmin();
        }
    }

   protected void GridMovieCancelEdit(object sender, GridViewCancelEditEventArgs e){
        gridMovieAdminList.EditIndex = -1;
    }

    protected void GridMovieEditRow(object sender, GridViewEditEventArgs e){
        GridViewRow row = gridMovieAdminList.Rows[e.NewEditIndex];
        string movieId = row.Cells[0].Text;
         Response.Redirect("EditMovie.aspx?MovieId=" + movieId);
    }

    protected void GridMovieAdminListRowDataBound(object sender, GridViewRowEventArgs e){
        if (e.Row.Cells[3].Text == "True"){
            e.Row.Cells[3].Text = "Yes";
        }
        if (e.Row.Cells[3].Text == "False"){
            e.Row.Cells[3].Text = "No";
        }
        if (e.Row.Cells[6].Text == "True"){
            e.Row.Cells[6].Text = "Yes";
        }
        if (e.Row.Cells[6].Text == "False") { 
            e.Row.Cells[6].Text = "No";
        }
        double value;
        if (double.TryParse(e.Row.Cells[2].Text, out value)){
            e.Row.Cells[2].Text = "$ &nbsp;" + value.ToString("N0");
        }


    }

    protected void DisplayMoviesAdmin(){
        MovieDaoSqlImpl movieDao = new MovieDaoSqlImpl();      
        List<Movie> movieList = movieDao.GetMovieListAdmin();
        gridMovieAdminList.DataSource = movieList;
        gridMovieAdminList.DataBind();
    }
}