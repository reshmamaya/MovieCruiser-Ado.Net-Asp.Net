﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;
using com.cognizant.movie.util;

public partial class _Default : System.Web.UI.Page
{
    FavoriteDaoSqlImpl favoriteDao = new FavoriteDaoSqlImpl();
   
    protected void Page_Load(object sender, EventArgs e){
        if (!IsPostBack){
           DisplayFavorites();
            lblMessage.Text = "";
        }
    }
    protected void GridFavoriteDeleteButtonClick(object sender, GridViewCommandEventArgs e){
        int rowIndex = int.Parse(e.CommandArgument.ToString());
        string movieId = gridFavorite.Rows[rowIndex].Cells[0].Text;
        favoriteDao.RemoveFavorite(1, long.Parse(movieId));     
        lblMessage.Text = "Movies removed from Favorites successfully";
    }


    protected void DisplayMovieAfterDeleted(object sender, GridViewDeleteEventArgs e){
             DisplayFavorites();
    }


    protected void TotalBudget(){
        FavoriteDaoSqlImpl favoriteDao = new FavoriteDaoSqlImpl();
        Favorites favorite = favoriteDao.GetAllFavorites(1);         
        lblTotalBudget.Text = "$ " + favorite.Total.ToString();
    }

   protected void GridFavoriteRowDataBound(object sender, GridViewRowEventArgs e){        
        if (e.Row.Cells[2].Text == "True"){
            e.Row.Cells[2].Text = "Yes";
        }
        if (e.Row.Cells[2].Text == "False"){
            e.Row.Cells[2].Text = "No";
        }
        double value;
        if (double.TryParse(e.Row.Cells[3].Text, out value))
        {
            e.Row.Cells[3].Text = "$ &nbsp;" + value.ToString("N0");
        }
    }
    protected void DisplayFavorites()
    {
        try
        {
            FavoriteDaoSqlImpl favoriteDao1 = new FavoriteDaoSqlImpl();
            gridFavorite.DataSource = favoriteDao1.GetAllFavorites(1).MovieList;
            gridFavorite.DataBind();
            TotalBudget();
        }
        catch (FavoriteEmptyException)
        {
            Response.Redirect("FavoriteEmpty.aspx");
        }
    }

}

