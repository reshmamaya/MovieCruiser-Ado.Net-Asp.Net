﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;
using System.Data.SqlClient;
using System.Data;

namespace com.cognizant.movie.dao{
   public  class FavoriteDaoSqlImpl : IFavoritesDao{

        static string _callConnection = ConnectionHandler.ConnectionVariable;
        public static string _addFavoriteData = "insert into favorite values(@userId,@movieId);";
        public static string _getAllFavorites = "select * from movie as mv join favorite as fv on mv.mv_id=fv.fv_mv_id where fv.fv_us_id= @userId;";
        public static string _countTotal = "select sum(mv.mv_budget) as Total from movie  as mv join favorite as fv on mv.mv_id=fv.fv_mv_id where fv.fv_us_id= @userId;";
        public static string _deleteMovie = "delete from favorite where fv_mv_id = @movieId and fv_us_id= @userId;";

        public void AddFavorite(long userId, long favoriteId){
            using (SqlConnection connection = new SqlConnection(_callConnection)){
                connection.Open();
                SqlCommand command = new SqlCommand{
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _addFavoriteData
                };

                command.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                command.Parameters.Add("@movieId", SqlDbType.Int).Value = favoriteId;

                command.ExecuteNonQuery();
            }
        }

        public Favorites GetAllFavorites(long userId){
            Favorites favorite = new Favorites();
            List<Movie> movieList = new List<Movie>();
            using (SqlConnection con = new SqlConnection(_callConnection)){
                con.Open();
                SqlCommand command = new SqlCommand{
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = _getAllFavorites
                };
                command.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                SqlDataReader dataReader = command.ExecuteReader();
                int count = 0;
                while (dataReader.Read()){
                    Movie movie = new Movie();
                    movie.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal("mv_id")));
                    movie.Title = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_title")));
                    movie.Budget = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal("mv_budget")));
                    movie.Active = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_active"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false;
                    movie.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal("mv_date_of_launch")));
                    movie.Genre = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_genre")));
                    movie.HasTeaser = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal("mv_has_teaser"))).Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    count++;
                    movieList.Add(movie);
                }
          
                if (count == 0) {
                    throw new FavoriteEmptyException();
                }
                favorite.MovieList = movieList;
                dataReader.Close();
                SqlCommand command1 = new SqlCommand{
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = _countTotal
                };
                command1.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                SqlDataReader dataReader1 = command1.ExecuteReader();
                while (dataReader1.Read()){
                    favorite.Total = Convert.ToDouble(dataReader1.GetValue(dataReader1.GetOrdinal("Total")));
                }
            }
            return favorite;
        }

        public void RemoveFavorite(long userId, long favoriteId){
            using (SqlConnection connection = new SqlConnection(_callConnection)){
                connection.Open();
                SqlCommand command = new SqlCommand{
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = _deleteMovie
                };
                command.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
                command.Parameters.Add("@movieId", SqlDbType.Int).Value = favoriteId;
                command.ExecuteNonQuery();
            }
        }
    }
}
