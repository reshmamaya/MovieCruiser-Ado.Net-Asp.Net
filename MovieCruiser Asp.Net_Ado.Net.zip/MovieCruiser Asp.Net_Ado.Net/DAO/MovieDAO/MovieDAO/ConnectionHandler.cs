﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.movie.dao { 
    class ConnectionHandler{

        static string _variable = ConfigurationManager.ConnectionStrings["db_connection"].ToString();  
        public static string ConnectionVariable{
            get{
                return _variable;

            }
        }
    }
}
